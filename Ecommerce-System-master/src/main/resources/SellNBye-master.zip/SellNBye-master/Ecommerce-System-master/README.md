# Ecommerce-System

clone the project to your local machine using  following command.
 $git bash https://github.com/thariii/Ecommerce-System.git

Create a database as 'ecom'

In the project folder there's file named application.properties. Change spring.datasource.username and spring.datasource.password with your databse username and password.

Open command prompt and give path to the projet folder and go to that folder

execute below commands
	mvn clean install -Dmaven.test.skip=true
	java.jar

open http://localhost:8080/#/ in your browser.

