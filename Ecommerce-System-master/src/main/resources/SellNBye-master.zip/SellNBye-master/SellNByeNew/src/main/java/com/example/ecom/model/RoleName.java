package com.example.ecom.model;

/**
 * Created by rajeevkumarsingh on 07/12/17.
 */
public enum  RoleName {
    ROLE_USER,
    ROLE_SELLER,
    ROLE_ADMIN
}
