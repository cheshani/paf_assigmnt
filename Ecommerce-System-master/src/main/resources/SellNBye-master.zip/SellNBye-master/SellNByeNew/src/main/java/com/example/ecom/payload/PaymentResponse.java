package com.example.ecom.payload;

public class PaymentResponse {
}
